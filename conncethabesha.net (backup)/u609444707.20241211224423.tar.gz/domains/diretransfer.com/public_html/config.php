<?php

@ini_set('upload_tmp_dir',dirname(__FILE__).'/oc-content/tmp'); if ( @ini_get('session.save_handler') === 'files' ) @ini_set('session.save_path',dirname(__FILE__).'/oc-content/tmp');

/**
 * The base MySQL settings of OSClass
 */
define('MULTISITE', 0);

/** MySQL database name for OSClass */
define('DB_NAME', 'u609444707_oz7V3');

/** MySQL database username */
define('DB_USER', 'u609444707_xpNKg');

/** MySQL database password */
define('DB_PASSWORD', 'NsSj8XSDQM');

/** MySQL hostname */
define('DB_HOST', '127.0.0.1');

/** Database Table prefix */
define('DB_TABLE_PREFIX', 'q2bi_');

define('REL_WEB_URL', '/');

define('WEB_PATH', 'https://diretransfer.com/');

?>